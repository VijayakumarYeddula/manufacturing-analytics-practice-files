Manufacturing Analytics for Engineers - practice data
Vijayakumar Reddy Yeddula, Mechanical Product Engineer
============================================================

Engxtech Manufacturing is a fictional plant: 12 machines on 3 lines,
April to September 2026. Every number in it is synthetic.
Use it freely to practise along with the course.

How to start
1. Unzip this folder somewhere easy to find, e.g. Documents\Engxtech.
2. Install Power BI Desktop (free, Microsoft Store, Windows only).
   You do not need an account or a paid licence.
3. In Section 1, open Power BI Desktop > Home > Excel workbook and pick
   1_Data\Plant_Analytics_Training_Data.xlsx. Close the workbook in Excel first.

What is inside
1_Data
  Plant_Analytics_Training_Data.xlsx  six tables plus a README sheet:
      Machines, Parts                  (things that exist)
      ProductionLog, MaintenanceLog,
      SensorReadings, QualityInspections (events that happened)
  Energy_Exports\                      one CSV per month, used in Section 4
                                       (combine a folder). The "- Copy" file is
                                       a deliberate duplicate: removing it is
                                       part of the exercise.

2_Templates
  Data_Dictionary_Template.xlsx        fill it in during Section 2
  Engxtech_Theme.json                  the course colours; import it in Section 8
                                       (Design > Import theme)

3_PowerBI_Files
  Section01_Finished.pbix              my file at the end of Section 1;
                                       compare with yours if you get stuck
  Section02_Start.pbix                 the starting point for Section 2
  Section02_Finished.pbix to
  Section09_Finished.pbix              my file at the end of each section;
                                       open the previous section's file to
                                       start a section you missed

The data has a few real-world problems hidden in it on purpose (blank
totals, error codes, inconsistent names). Finding them is part of the job,
so please don't "fix" the workbook itself; clean the data in Power BI.

If Refresh can't find the data
The finished files remember the folder they were built in. If Refresh shows
an error: Home > Transform data > Data source settings > Change Source...
and point to 1_Data\Plant_Analytics_Training_Data.xlsx (and, from Section 4,
to the 1_Data\Energy_Exports folder). Then Close > Apply changes.

All nine sections are included.
